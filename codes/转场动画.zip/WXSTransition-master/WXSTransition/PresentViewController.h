//
//  PresentViewController.h
//  WXSTransition
//
//  Created by 王小树 on 16/6/1.
//  Copyright © 2016年 王小树. All rights reserved.
//

#import "WXSBaseViewController.h"
@interface PresentViewController : WXSBaseViewController

@end
