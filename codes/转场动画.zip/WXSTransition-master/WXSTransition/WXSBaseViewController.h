//
//  WXSBaseViewController.h
//  WXSTransition
//
//  Created by thejoyrun on 16/7/8.
//  Copyright © 2016年 王小树. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WXSBaseViewController : UIViewController

@end
