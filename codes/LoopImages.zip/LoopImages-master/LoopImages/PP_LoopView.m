#import "PP_LoopView.h"

#define kScreenH [UIScreen mainScreen].bounds.size.height
#define kScreenW [UIScreen mainScreen].bounds.size.width

@interface PP_LoopView ()
@property (assign, nonatomic) NSInteger currentIndex;// 当前展示视图对应的下标
@property (assign, nonatomic) NSInteger nextIndex; // 对应的下一个坐标
@property (assign, nonatomic) NSInteger previousIndex;// 对应上一个坐标
@property (strong, nonatomic) UIPanGestureRecognizer *pan;// 手势
@property (strong, nonatomic) NSArray<NSString *> *imageNames;// 存照片的名字数组
@property (strong, nonatomic) UIImageView *currentImage;// 当前展示的照片
@property (strong, nonatomic) UIImageView *nextImage; // 将要展示的照片
@property (strong, nonatomic) NSTimer *changeImageTime; // 定时器
@end
@implementation PP_LoopView

- (NSInteger)nextIndex {
    return _currentIndex == _imageNames.count - 1 ? 0 : _currentIndex + 1;
}

- (NSInteger)previousIndex {
    return _currentIndex == 0 ? _imageNames.count - 1 : _currentIndex - 1;
}

- (UIImage *)getImageForIndex:(NSInteger)index {
    return [UIImage imageNamed:[NSString stringWithFormat:@"LoopImg.bundle/%@",_imageNames[index]]];
}

- (instancetype)initWithImageArray:(NSArray <NSString *>*)imageArray
                              fram:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        _imageNames = imageArray;
        _currentIndex = 0;
        _currentImage = [[UIImageView alloc] initWithFrame:self.bounds];
        _currentImage.userInteractionEnabled = YES;
        _currentImage.image = [self getImageForIndex:_currentIndex];
        [self insertSubview:_currentImage atIndex:1];
        _nextImage = [[UIImageView alloc] init];
        _nextImage.userInteractionEnabled = YES;
        [self insertSubview:_nextImage atIndex:0];
        _pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panChangeImage:)];
        [self addGestureRecognizer:_pan];
        [self addTime];
    }
    return self;
}

- (void)addTime {
    _changeImageTime = [NSTimer scheduledTimerWithTimeInterval:1.5f target:self selector:@selector(changeActionForTime) userInfo:nil repeats:YES];
}

- (void)changeActionForTime {
    self.nextImage.image = [self getImageForIndex:self.nextIndex];
    self.nextImage.frame = CGRectOffset(_currentImage.frame, kScreenW, 0);
    [self leftOut:self.currentImage rightIn:self.nextImage duration:0.5f];
    self.currentIndex = self.nextIndex;
    UIImageView *temp = self.nextImage;
    self.nextImage = self.currentImage;
    self.currentImage = temp;
}

- (void)panChangeImage:(UIPanGestureRecognizer *)pan {
    [self.changeImageTime invalidate];
    self.changeImageTime = nil;
    CGPoint panOffSet = [pan translationInView:self];
    float changeX = panOffSet.x;
    CGRect frame = _currentImage.frame;
    [_pan setTranslation:(CGPointZero) inView:self];
    float resulet = frame.origin.x + (changeX < 0 ? - DBL_EPSILON : DBL_EPSILON);
    resulet <= 0 ? [self leftScroll:changeX frame:frame] : [self rightScroll:changeX frame:frame] ;
}

- (void)leftScroll:(float)offX
             frame:(CGRect)frame {
    float tempX = frame.origin.x + offX;
    _currentImage.frame = CGRectMake(tempX, frame.origin.y, frame.size.width, frame.size.height);
    _nextImage.image = [self getImageForIndex:self.nextIndex];
    _nextImage.frame = CGRectOffset(_currentImage.frame, kScreenW, 0);
    if (_pan.state == UIGestureRecognizerStateEnded) {
        [self addTime];
        MoveDirection result = tempX <= - kScreenW / 2 ? [self leftOut:_currentImage rightIn:_nextImage duration:0.3f] : [self leftIn:_currentImage rightOut:_nextImage duration:0.3f];
        if (result == MoveDirectionLeft) {
            _currentIndex = self.nextIndex;
            UIImageView *temp = _nextImage;
            _nextImage = _currentImage;
            _currentImage = temp;
        }
    }
}

- (void)rightScroll:(float)offX
              frame:(CGRect)frame {
    float tempX = frame.origin.x + offX;
    _currentImage.frame = CGRectMake(tempX, frame.origin.y, frame.size.width, frame.size.height);
    _nextImage.image = [self getImageForIndex:self.previousIndex];
    _nextImage.frame = CGRectOffset(_currentImage.frame, -kScreenW, 0);
    if (_pan.state == UIGestureRecognizerStateEnded) {
        [self addTime];
        MoveDirection result = tempX <= kScreenW / 2 ? [self leftOut:_nextImage rightIn:_currentImage duration:0.3f] : [self leftIn:_nextImage rightOut:_currentImage duration:0.3f];
        if (result == MoveDirectionRight) {
            _currentIndex = self.previousIndex;
            UIImageView *temp = _nextImage;
            _nextImage = _currentImage;
            _currentImage = temp;
        }
    }
}

- (MoveDirection)leftOut:(UIImageView *)leftView
                 rightIn:(UIImageView *)rightView
                duration:(NSTimeInterval)duration {
    [UIView animateWithDuration:duration animations:^{
        leftView.frame = CGRectOffset(self.bounds, - kScreenW, 0);
        rightView.frame = self.bounds;
    }];
    return MoveDirectionLeft;
}

- (MoveDirection)leftIn:(UIImageView *)leftView
               rightOut:(UIImageView *)rightView
               duration:(NSTimeInterval)duration {
    [UIView animateWithDuration:duration animations:^{
        rightView.frame = CGRectOffset(self.bounds, kScreenW, 0);
        leftView.frame = self.bounds;
    }];
    return MoveDirectionRight;
}

@end
