#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    MoveDirectionLeft,
    MoveDirectionRight,
} MoveDirection;

@interface PP_LoopView : UIView

- (instancetype)initWithImageArray:(NSArray <NSString *>*)imageArray
                              fram:(CGRect)frame;

@end
